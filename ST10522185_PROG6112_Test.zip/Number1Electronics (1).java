import java.util.Scanner;

public class Number1Electronics{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String[] cities = { "Cape Town", "Port Elizabeth", "Pretoria"};
        
        int[][] consoles = new int[3][3];
        
        int[] cityTotals = new int[3];
        
        for( int i = 0; i < cities.length; i++) {
            System.out.print("Enter the number of sales for " + cities[i] + ": ");
            consoles[i][0]= scanner.nextInt();
            
        }
        for( int i = 0; i < cities.length; i++) {
            System.out.print("Enter the number of sales for " + cities[i] + ": ");
            consoles[i][0]= scanner.nextInt();
        }
        for( int i = 0; i < cities.length; i++) {
            System.out.print("Enter the number of sales for " + cities[i] + ": ");
            consoles[i][0]= scanner.nextInt();
            
        for( int i = 0; i < cities.length; i++) {
            cityTotals[i] = consoles[i][0] + consoles[i][1] + consoles[i][2];
        }
        
        System.out.println("\n---------------------------------------");
        System.out.println("GAMING CONSOLE REPORT");
        System.out.println("----------------------------------------");
        System.out.printf("PS5", " XBOX", "MOTORBIKE");
        
        for ( int i = 0; i < cities.length; i++) {
            System.out.printf("%-20s%-15d\n", cities[i], cityTotals[i]);
            
        }
        System.out.println("\n---------------------------------------");
        System.out.println("CONSOLES SALES TOTAL FOR EACH CITY");
        System.out.println("----------------------------------------");
        
        int maxIndex = 0;
        for( int i = 0; i < cities.length; i++) {
            System.out.printf("%-20s%-15d\n",cities[i], cityTotals[i]);
            
            if (cityTotals[i] > cityTotals[maxIndex]) {
                maxIndex = i;
            }
        }
        System.out.println("\n---------------------------------------");
        System.out.println("CITY WITH THE MOST SALES: " + cities[maxIndex].toUpperCase());
        System.out.println("----------------------------------------");
    }
}